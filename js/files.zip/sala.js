/* =====================================================
   sala.js — Sala Virtual dos Arcanos (protótipo)
   Three.js 0.160.0 via import map (ver index.html)
   Seções: 1 Configuração · 2 Dados · 3 Janela ampliada
           4 Alternativa sem 3D · 5 Cena 3D · 6 Início
   ===================================================== */

/* ── 1. CONFIGURAÇÃO (ajuste aqui nos próximos testes) ── */
const CONFIG = {
  base: '/img/arcanos/',
  sala: { largura: 6, comprimento: 18, altura: 4 },       // metros
  moldura: { proporcao: 0.04, profundidade: 0.05 },        // 4% da largura da obra
  quadro: { altura: 1.4, proporcaoPadrao: 199 / 288 },     // usada só até a foto carregar
  camera: {
    fov: 50, alturaOlhos: 1.55, alturaAlvo: 1.42,
    distancia: 2.6, distanciaRetrato: 3.4,                 // distância diante da obra (tela larga / estreita)
    duracao: 2.4,                                          // segundos por deslocamento
    entrada: { x: 0, y: 1.6, z: 7.6, alvoZ: -2 },
  },
  fio: { raio: 0.014, cor: 0xc49a50 },
  luz: { ambiente: 0.9, foco: 18 },
};

/* ── 2. DADOS (mesmos textos da página da exposição) ── */
// x, z = posição do cavalete; lado = 1 → obra voltada para +x (parede esquerda); -1 → para -x (direita)
const OBRAS = [
  { romano: 'III',  nome: 'A Imperatriz', arquivo: '03-a-imperatriz',
    frase: 'A criação que floresce quando é cuidada.',
    pergunta: 'O que em você pede para nascer?', x: -2, z: 3, lado: 1 },
  { romano: 'XIII', nome: 'A Morte', arquivo: '13-a-morte',
    frase: 'O que termina abre espaço para o que vem.',
    pergunta: 'O que já cumpriu o seu tempo?', x: 2, z: -1, lado: -1 },
  { romano: 'XIX',  nome: 'O Sol', arquivo: '19-o-sol',
    frase: 'A clareza, a alegria e a vida à luz do dia.',
    pergunta: 'O que merece ser celebrado agora?', x: -2, z: -5, lado: 1 },
];

const $ = (id) => document.getElementById(id);
const reduzido = matchMedia('(prefers-reduced-motion: reduce)').matches;
const urlFoto = (o, mini = false) => `${CONFIG.base}${o.arquivo}${mini ? '-mini' : ''}.webp`;

function aviso(texto) {
  const p = document.createElement('p');
  p.textContent = texto;
  $('avisos').append(p);
}

/* ── 3. JANELA AMPLIADA ── */
const dlg = $('ampliada');
let origemFoco = null;
let aoFechar = null;

function abrirAmpliada(i, origem) {
  const o = OBRAS[i];
  origemFoco = origem || null;

  const area = $('amp-foto');
  area.replaceChildren();
  const img = new Image();
  img.alt = `Bordado do Arcano ${o.nome}, ampliado`;
  img.decoding = 'async';
  img.addEventListener('error', () => {
    const p = document.createElement('p');
    p.className = 'erro';
    p.textContent = `Não encontrei a fotografia de ${o.nome} em ${urlFoto(o)}. Confira se o arquivo existe na pasta img/arcanos/.`;
    area.replaceChildren(p);
  });
  img.src = urlFoto(o);
  area.append(img);

  $('amp-numero').textContent = `ARCANO ${o.romano}`;
  $('amp-nome').textContent = o.nome;
  $('amp-frase').textContent = o.frase;
  $('amp-pergunta').textContent = o.pergunta;
  if (!dlg.open) dlg.showModal();
}

$('amp-fechar').addEventListener('click', () => dlg.close());
$('amp-voltar').addEventListener('click', () => dlg.close());
dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
dlg.addEventListener('close', () => {
  if (aoFechar) aoFechar();
  if (origemFoco && origemFoco.focus) origemFoco.focus();
});

/* ── 4. ALTERNATIVA SEM 3D ── */
document.querySelectorAll('#alternativa a[data-i]').forEach((a) => {
  a.addEventListener('click', (e) => { e.preventDefault(); abrirAmpliada(Number(a.dataset.i), a); });
});
document.querySelectorAll('#alternativa img').forEach((img) => {
  img.addEventListener('error', () => {
    const s = document.createElement('span');
    s.textContent = '(fotografia não encontrada)';
    img.replaceWith(s);
  });
});

function alternativa(motivo) {
  document.body.classList.add('sem-3d');
  $('alt-motivo').textContent = `${motivo} Veja os bordados abaixo.`;
  $('alternativa').hidden = false;
}

/* ── 5. CENA 3D ── */
function iniciar(THREE) {
  const cont = $('cena');
  const renderer = new THREE.WebGLRenderer({ antialias: true }); // lança erro se não houver WebGL
  const mobile = matchMedia('(pointer: coarse)').matches || innerWidth < 700;
  const anis = Math.min(4, renderer.capabilities.getMaxAnisotropy());
  cont.append(renderer.domElement);

  const cena = new THREE.Scene();
  cena.background = new THREE.Color(0x2a241c);
  const camera = new THREE.PerspectiveCamera(CONFIG.camera.fov, 1, 0.1, 60);

  const mat = (cor, rug = 0.9, met = 0) =>
    new THREE.MeshStandardMaterial({ color: cor, roughness: rug, metalness: met });

  /* Sala: paredes/teto (caixa vista por dentro), piso, rodapés */
  const { largura: L, comprimento: C, altura: A } = CONFIG.sala;
  const paredes = new THREE.Mesh(
    new THREE.BoxGeometry(L, A, C),
    new THREE.MeshStandardMaterial({ color: 0xebe4d6, roughness: 0.95, side: THREE.BackSide })
  );
  paredes.position.y = A / 2;
  cena.add(paredes);

  const piso = new THREE.Mesh(
    new THREE.PlaneGeometry(L, C),
    new THREE.MeshStandardMaterial({ map: texturaMadeira(THREE, anis), roughness: 0.75 })
  );
  piso.rotation.x = -Math.PI / 2;
  piso.position.y = 0.002;
  cena.add(piso);

  const rodape = mat(0xcfc6b4, 0.8);
  [[0.03, 0.12, C, -(L / 2 - 0.015), 0], [0.03, 0.12, C, L / 2 - 0.015, 0],
   [L, 0.12, 0.03, 0, -(C / 2 - 0.015)], [L, 0.12, 0.03, 0, C / 2 - 0.015]].forEach(([w, h, d, x, z]) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), rodape);
    m.position.set(x, 0.06, z);
    cena.add(m);
  });

  /* Fio dourado sinuoso no piso */
  const pontos = [];
  for (let z = C / 2 - 0.8; z >= -C / 2 + 0.8; z -= 0.5) {
    pontos.push(new THREE.Vector3(1.1 * Math.sin(z * 0.7) + 0.4 * Math.sin(z * 1.9 + 1), 0.016, z));
  }
  const fio = new THREE.Mesh(
    new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pontos), 240, CONFIG.fio.raio, 6, false),
    new THREE.MeshStandardMaterial({ color: CONFIG.fio.cor, roughness: 0.4, metalness: 0.3, emissive: 0x3d2c0a })
  );
  cena.add(fio);

  /* Luz geral suave */
  cena.add(new THREE.HemisphereLight(0xfff4e0, 0x8a6a4a, CONFIG.luz.ambiente));

  /* Cavaletes, molduras e luzes individuais */
  const fotos = [];
  const preto = mat(0x0e0e0e, 0.95);
  const madeira = mat(0x7b5333, 0.7);
  const unidade = new THREE.BoxGeometry(1, 1, 1);

  function criarObra(o, i) {
    const g = new THREE.Group();
    g.position.set(o.x, 0, o.z);
    g.rotation.y = o.lado * Math.PI / 2;     // +z local aponta para o centro da sala
    cena.add(g);

    const peca = (sx, sy, sz, px, py, pz, rx = 0) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), madeira);
      m.position.set(px, py, pz); m.rotation.x = rx; g.add(m);
    };
    peca(0.06, 2.1, 0.06, -0.55, 1.05, 0, -0.08);   // hastes frontais
    peca(0.06, 2.1, 0.06, 0.55, 1.05, 0, -0.08);
    peca(0.06, 2.02, 0.06, 0, 0.95, -0.45, 0.353);   // perna traseira
    peca(1.25, 0.05, 0.2, 0, 0.62, 0.1);             // apoio da obra
    peca(1.2, 0.05, 0.06, 0, 2.02, -0.02);           // barra superior

    const q = new THREE.Group();                      // quadro (moldura + foto)
    g.add(q);
    const partes = Array.from({ length: 5 }, () => { const m = new THREE.Mesh(unidade, preto); q.add(m); return m; });
    const matFoto = new THREE.MeshStandardMaterial({ color: 0xd9cdb5, roughness: 0.9 });
    const foto = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), matFoto);
    foto.position.z = 0.015;
    foto.userData.i = i;
    q.add(foto);
    fotos.push(foto);

    const obra = { o, matFoto, centro: new THREE.Vector3(), cheia: false, carregando: false };

    // Ajusta foto e moldura à proporção real da fotografia (sem cortes nem distorção)
    function ajustar(aspecto) {
      const h = CONFIG.quadro.altura, w = h * aspecto;
      const t = w * CONFIG.moldura.proporcao, d = CONFIG.moldura.profundidade;
      const [topo, base, esq, dir, fundo] = partes;
      foto.scale.set(w, h, 1);
      topo.scale.set(w + 2 * t, t, d);  topo.position.set(0, h / 2 + t / 2, 0);
      base.scale.copy(topo.scale);      base.position.set(0, -(h / 2 + t / 2), 0);
      esq.scale.set(t, h, d);           esq.position.set(-(w / 2 + t / 2), 0, 0);
      dir.scale.copy(esq.scale);        dir.position.set(w / 2 + t / 2, 0, 0);
      fundo.scale.set(w + 2 * t, h + 2 * t, 0.02); fundo.position.set(0, 0, -0.02);
      q.position.set(0, 0.67 + h / 2 + t, 0.1);
      q.rotation.x = -0.08;
      g.updateMatrixWorld(true);
      q.getWorldPosition(obra.centro);
    }
    ajustar(CONFIG.quadro.proporcaoPadrao);

    obra.aplicar = (tex) => {
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = anis;
      if (matFoto.map) matFoto.map.dispose();
      matFoto.map = matFoto.emissiveMap = tex;     // emissivo leve preserva as cores originais
      matFoto.color.set(0xffffff);
      matFoto.emissive.set(0xffffff);
      matFoto.emissiveIntensity = 0.35;
      matFoto.needsUpdate = true;
      ajustar(tex.image.width / tex.image.height);
    };

    // Luz individual
    const luz = new THREE.SpotLight(0xfff0d8, CONFIG.luz.foco, 8, 0.5, 0.8, 2);
    luz.position.set(o.x + o.lado * 1.3, 3.4, o.z);
    luz.target.position.set(o.x, CONFIG.camera.alturaAlvo, o.z);
    cena.add(luz, luz.target);

    return obra;
  }
  const obras = OBRAS.map(criarObra);

  /* Texturas: miniatura primeiro; foto grande ao chegar diante da obra */
  const carregador = new THREE.TextureLoader();
  const carregar = (url) => new Promise((ok, falha) => carregador.load(url, ok, undefined, falha));

  async function carregarInicial(obra) {
    try { obra.aplicar(await carregar(urlFoto(obra.o, true))); return; } catch (e) { /* tenta a grande */ }
    try { obra.aplicar(await carregar(urlFoto(obra.o))); obra.cheia = true; return; } catch (e) { /* placeholder */ }
    obra.cheia = true;
    obra.aplicar(texturaAusente(THREE, obra.o));
    aviso(`Não encontrei a fotografia de ${obra.o.nome} (${urlFoto(obra.o)}). Confira o arquivo na pasta img/arcanos/.`);
  }
  async function carregarCheia(obra) {
    if (obra.cheia || obra.carregando) return;
    obra.carregando = true;
    try { obra.aplicar(await carregar(urlFoto(obra.o))); obra.cheia = true; }
    catch (e) { obra.carregando = false; }   // mantém a miniatura
  }
  obras.forEach(carregarInicial);

  /* Navegação guiada */
  let indice = -1;          // -1 = entrada da sala
  let anim = null;
  const alvoAtual = new THREE.Vector3();
  const E = CONFIG.camera.entrada;

  function destinoDe(i) {
    if (i < 0) return { pos: new THREE.Vector3(E.x, E.y, E.z), alvo: new THREE.Vector3(0, CONFIG.camera.alturaAlvo, E.alvoZ) };
    const ob = obras[i], o = ob.o;
    const dist = camera.aspect < 0.8 ? CONFIG.camera.distanciaRetrato : CONFIG.camera.distancia;
    return {
      pos: new THREE.Vector3(o.x + o.lado * dist, CONFIG.camera.alturaOlhos, o.z),
      alvo: ob.centro.clone(),
    };
  }
  function colocar(d) {
    camera.position.copy(d.pos);
    alvoAtual.copy(d.alvo);
    camera.lookAt(alvoAtual);
  }
  function textoParada() {
    return indice < 0
      ? 'Entrada da sala. Use Próximo para iniciar o passeio.'
      : `Parada ${indice + 1} de ${OBRAS.length}: Arcano ${OBRAS[indice].romano}, ${OBRAS[indice].nome}`;
  }
  function atualizarUI() {
    $('btn-ant').disabled = indice < 0;
    $('btn-prox').disabled = indice >= OBRAS.length - 1;
    $('btn-ampliar').disabled = indice < 0;
  }
  function irPara(i) {
    indice = Math.max(-1, Math.min(OBRAS.length - 1, i));
    const d = destinoDe(indice);
    atualizarUI();
    if (indice >= 0) carregarCheia(obras[indice]);
    if (reduzido) { anim = null; colocar(d); $('status').textContent = textoParada(); return; }
    anim = {
      t0: performance.now(), dur: CONFIG.camera.duracao * 1000,
      p0: camera.position.clone(), a0: alvoAtual.clone(), p1: d.pos, a1: d.alvo,
    };
    $('status').textContent = indice < 0 ? 'Voltando à entrada…' : `Caminhando até ${OBRAS[indice].nome}…`;
  }
  function pausar() { anim = null; }          // interrompe o deslocamento onde estiver

  $('btn-ant').addEventListener('click', () => irPara(indice - 1));
  $('btn-prox').addEventListener('click', () => irPara(indice + 1));
  $('btn-ampliar').addEventListener('click', (e) => {
    if (indice < 0) return;
    pausar();
    abrirAmpliada(indice, e.currentTarget);
  });
  // Ao fechar a janela, a câmera permanece parada até o visitante escolher continuar
  aoFechar = () => {
    $('status').textContent = indice < 0
      ? textoParada()
      : `${textoParada()} — parado. Use Anterior ou Próximo para continuar.`;
  };

  document.addEventListener('keydown', (e) => {
    if (dlg.open || e.altKey || e.ctrlKey || e.metaKey) return;
    if (e.key === 'ArrowRight' && indice < OBRAS.length - 1) irPara(indice + 1);
    if (e.key === 'ArrowLeft' && indice >= 0) irPara(indice - 1);
  });

  /* Toque/clique direto no bordado */
  const raio = new THREE.Raycaster();
  const ndc = new THREE.Vector2();
  function obraEm(e) {
    const r = renderer.domElement.getBoundingClientRect();
    ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    raio.setFromCamera(ndc, camera);
    const hit = raio.intersectObjects(fotos, false)[0];
    return hit ? hit.object.userData.i : -1;
  }
  let toque = null;
  const tela = renderer.domElement;
  tela.addEventListener('pointerdown', (e) => { toque = { x: e.clientX, y: e.clientY }; });
  tela.addEventListener('pointerup', (e) => {
    if (!toque) return;
    const moveu = Math.hypot(e.clientX - toque.x, e.clientY - toque.y);
    toque = null;
    if (moveu > 8) return;
    const i = obraEm(e);
    if (i < 0) return;
    pausar();
    indice = i;
    atualizarUI();
    carregarCheia(obras[i]);
    abrirAmpliada(i, $('btn-ampliar'));
  });
  tela.addEventListener('pointermove', (e) => {
    if (e.pointerType === 'mouse') tela.style.cursor = obraEm(e) >= 0 ? 'pointer' : 'default';
  });

  /* Tamanho e desempenho */
  function redimensionar() {
    const w = cont.clientWidth, h = cont.clientHeight;
    renderer.setPixelRatio(Math.min(devicePixelRatio || 1, mobile ? 1.5 : 2));
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    if (!anim) colocar(destinoDe(indice));
  }
  addEventListener('resize', redimensionar);

  /* Início */
  redimensionar();
  irPara(-1);
  atualizarUI();
  $('status').textContent = textoParada();
  anim = null;
  colocar(destinoDe(-1));

  let carregandoEl = $('carregando');
  renderer.setAnimationLoop((agora) => {
    if (anim) {
      const k = Math.min((agora - anim.t0) / anim.dur, 1);
      const e = k * k * (3 - 2 * k);                      // suaviza partida e chegada
      camera.position.lerpVectors(anim.p0, anim.p1, e);
      alvoAtual.lerpVectors(anim.a0, anim.a1, e);
      camera.lookAt(alvoAtual);
      if (k >= 1) { anim = null; $('status').textContent = textoParada(); }
    }
    renderer.render(cena, camera);
    if (carregandoEl) { carregandoEl.remove(); carregandoEl = null; }
  });
}

/* Piso de madeira gerado por código (sem imagem extra) */
function texturaMadeira(THREE, anis) {
  const c = document.createElement('canvas');
  c.width = c.height = 512;
  const g = c.getContext('2d');
  const n = 8, w = c.width / n;
  for (let i = 0; i < n; i++) {
    g.fillStyle = `hsl(28 32% ${38 + Math.random() * 10}%)`;
    g.fillRect(i * w, 0, w, 512);
    g.strokeStyle = 'rgba(60,35,15,.12)';
    for (let k = 0; k < 14; k++) {
      const x = i * w + Math.random() * w;
      g.beginPath(); g.moveTo(x, 0); g.lineTo(x + (Math.random() - 0.5) * 6, 512); g.stroke();
    }
    g.fillStyle = 'rgba(40,22,8,.55)';
    g.fillRect(i * w, 0, 2, 512);
    g.fillRect(i * w, (Math.random() * 400 + 50) | 0, w, 2);
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(CONFIG.sala.largura / (n * 0.12), CONFIG.sala.comprimento / 1.5);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = anis;
  return t;
}

/* Tela neutra exibida no cavalete quando a fotografia não existe */
function texturaAusente(THREE, o) {
  const c = document.createElement('canvas');
  c.width = 300; c.height = 420;
  const g = c.getContext('2d');
  g.fillStyle = '#e8d9b8'; g.fillRect(0, 0, 300, 420);
  g.fillStyle = '#a07830'; g.textAlign = 'center';
  g.font = '64px Georgia, serif'; g.fillText(o.romano, 150, 200);
  g.font = '18px system-ui, sans-serif'; g.fillText('Fotografia não encontrada', 150, 250);
  return new THREE.CanvasTexture(c);
}

/* ── 6. INÍCIO ── */
async function principal() {
  let THREE;
  try {
    THREE = await import('three');
  } catch (e) {
    console.error(e);
    return alternativa('Não foi possível carregar a biblioteca 3D (verifique a conexão com a internet).');
  }
  try {
    iniciar(THREE);
  } catch (e) {
    console.error(e);
    alternativa('Este navegador não conseguiu iniciar o ambiente 3D (WebGL indisponível).');
  }
}
principal();
